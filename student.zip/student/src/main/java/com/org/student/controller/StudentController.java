package com.org.student.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.org.student.entity.Student;
import com.org.student.service.StudentService;

import java.util.List;

@RestController
@RequestMapping("/students")
public class StudentController {

	@Autowired
	private StudentService studentService;

	// Create a new student
	@PostMapping("/create")
	public Student createStudent(@RequestBody Student student) {
		return studentService.saveStudent(student);
	}

	// Get all students
	@GetMapping("/all")
	public List<Student> getAllStudents() {
		return studentService.getAllStudents();
	}

	// Get students between age 18 and 25
	@GetMapping("/age-range")
	public List<Student> getStudentsBetween18and25() {
		return studentService.getStudentsBetween18and25();
	}

	// Update student's age based on DOB
	@PutMapping("/update-age/{id}")
	public Student updateStudentAge(@PathVariable Long id,@RequestBody Student student) {
		return studentService.updateStudentAge(id,student);
	}
}
