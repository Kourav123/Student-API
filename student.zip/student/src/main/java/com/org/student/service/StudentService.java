package com.org.student.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.org.student.entity.Student;
import com.org.student.repository.StudentRepository;

import java.time.LocalDate;
import java.time.Period;
import java.util.List;
import java.util.Objects;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    public Student saveStudent(Student student) {
    	
        student.calculateAge();
        return studentRepository.save(student);
    }

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public List<Student> getStudentsBetween18and25() {
        return studentRepository.findByAgeBetween(18, 25);
    }

    public Student getStudentById(Long id) {
        return studentRepository.findById(id).orElse(null);
    }

    public Student updateStudentAge(Long id,Student studentRes) {
        Student student = getStudentById(id);
        if (Objects.nonNull(student)) {
        	student.setAge(Period.between(LocalDate.of(studentRes.getYearOfBirth(), studentRes.getMonthOfBirth(), studentRes.getDayOfBirth()), LocalDate.now()).getYears());
        	student.setDayOfBirth(studentRes.getDayOfBirth());
        	student.setId(id);
        	student.setName(studentRes.getName());
        	student.setMonthOfBirth(studentRes.getMonthOfBirth());
		}
      
        return studentRepository.save(student);
    }
}

