package com.org.student.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.org.student.entity.Student;

import java.util.List;

public interface StudentRepository extends JpaRepository<Student, Long> {
    List<Student> findByAgeBetween(int minAge, int maxAge);
}

